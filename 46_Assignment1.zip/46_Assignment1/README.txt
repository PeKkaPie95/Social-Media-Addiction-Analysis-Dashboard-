# CS661 Assignment 1 - Isocontour and Volume Visualization
# Group Number: 46

---

## Part 1: 2D Isocontour Extraction

### How to Run

1. Please have `Isabel_2D.vti` is in the same folder.
2. Run the script using: 
   python part1.py Isabel_2D.vti <isovalue> <output.vtp>

( Run the example below in the terminal after executing the code.)

Example:

   python part1.py Isabel_2D.vti -300 contour_output.vtp

3. Open the `.vtp` file in ParaView to view the isocontour.
( It should be saved in the same folder.) 

---

## Part 2: 3D Volume Rendering

### How to Run

1. Please have `Isabel_3D.vti` is in the same folder.
2. Run the script using any one of the following (as per the required output):

   python part2.py Isabel_3D.vti yes    # enables Phong shading  
   python part2.py Isabel_3D.vti no     # disables Phong shading

3. A 1000x1000 render window will open showing the volume and outline.
   Also the front and back view will be saved as png files(can be safely deleted if unnecessary).

---

## Notes

- For Part 1, valid isovalues are between -1438 and 630.
- For Part 2, only use "yes" or "no" for the shading option (not 1/0).
- Make sure VTK is installed:

   pip install vtk
(Run this in command prompt and we are done!!!)


