import vtk
import sys

def interpolate(p1, v1, p2, v2, isovalue):
    """Linearly interpolate to find the intersection point on an edge."""
    t = (isovalue - v1) / (v2 - v1)
    return [p1[i] + t*(p2[i] - p1[i]) for i in range(3)]

def main(vti_file, isovalue, output_vtp):
    #Read the 2D VTI dataset
    reader = vtk.vtkXMLImageDataReader()
    reader.SetFileName(vti_file)
    reader.Update()
    image_data = reader.GetOutput()

    dims = image_data.GetDimensions()     
    spacing = image_data.GetSpacing()     
    origin = image_data.GetOrigin()     
    scalars = image_data.GetPointData().GetScalars()

    points = vtk.vtkPoints()
    lines = vtk.vtkCellArray()
    point_id = 0

    nx, ny = dims[0], dims[1]

    #Traverse each cell
    for i in range(nx - 1):
        for j in range(ny - 1):
            cell_points = []
            cell_values = []

            #Get the 4 corners in counterclockwise order(bottomleft, bottomright, topright, topleft)
            for dx, dy in [(0,0), (1,0), (1,1), (0,1)]:
                x = origin[0] + (i + dx)*spacing[0]
                y = origin[1] + (j + dy)*spacing[1]
                z = 0
                pt_id = (j + dy)*nx + (i + dx)
                v = scalars.GetTuple1(pt_id)
                cell_points.append((x, y, z))
                cell_values.append(v)

            #Edges: bottom, right, top, left(indices of corner pairs)
            edge_pairs = [(0,1), (1,2), (2,3), (3,0)]
            intersections = []

            for idx0, idx1 in edge_pairs:
                v0, v1 = cell_values[idx0], cell_values[idx1]
                if (v0 - isovalue)*(v1 - isovalue) < 0:  # Sign change = contour crosses
                    pt = interpolate(cell_points[idx0], v0, cell_points[idx1], v1, isovalue)
                    intersections.append(pt)

            # Add line segment if exactly 2 intersection points
            if len(intersections) == 2:
                id1 = point_id
                points.InsertNextPoint(intersections[0])
                point_id += 1
                id2 = point_id
                points.InsertNextPoint(intersections[1])
                point_id += 1

                line = vtk.vtkLine()
                line.GetPointIds().SetId(0, id1)
                line.GetPointIds().SetId(1, id2)
                lines.InsertNextCell(line)

    #Build the output PolyData
    polydata = vtk.vtkPolyData()
    polydata.SetPoints(points)
    polydata.SetLines(lines)

    #Write to .vtp file
    writer = vtk.vtkXMLPolyDataWriter()
    writer.SetFileName(output_vtp)
    writer.SetInputData(polydata)
    writer.Write()

    print(f"Isocontour extracted at isovalue {isovalue} and written to '{output_vtp}'")


if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python extract_isocontour.py <input.vti> <isovalue> <output.vtp>")  
        sys.exit(1)

    vti_file = sys.argv[1]
    isovalue = float(sys.argv[2])
    output_vtp = sys.argv[3]

    main(vti_file, isovalue, output_vtp)
