import vtk
import sys
import os

def main(vti_file, use_phong):
    #Check if file exists
    if not os.path.isfile(vti_file):
        print(f"Error: File '{vti_file}' does not exist.")
        sys.exit(1)

    #Read the 3D VTI dataset
    reader = vtk.vtkXMLImageDataReader()
    reader.SetFileName(vti_file)
    reader.Update()
    data = reader.GetOutput()

    #Print scalar range for debugging
    scalars = data.GetPointData().GetScalars()
    scalar_range = scalars.GetRange()
    print("Scalar Range of the 3D volume data: ", scalar_range)


    #Color Transfer Function
    colorFunc = vtk.vtkColorTransferFunction()
    colorFunc.AddRGBPoint(-4931.54, 0.0, 1.0, 1.0)
    colorFunc.AddRGBPoint(-2508.95, 0.0, 0.0, 1.0)
    colorFunc.AddRGBPoint(-1873.9,  0.0, 0.0, 0.5)
    colorFunc.AddRGBPoint(-1027.16, 1.0, 0.0, 0.0)
    colorFunc.AddRGBPoint(-298.031, 1.0, 0.4, 0.0)
    colorFunc.AddRGBPoint(2594.97,  1.0, 1.0, 0.0)

    #Opacity Transfer Function
    opacityFunc = vtk.vtkPiecewiseFunction()
    opacityFunc.AddPoint(-4931.54, 1.0)
    opacityFunc.AddPoint(101.815,  0.002)
    opacityFunc.AddPoint(2594.97,  0.0)

    #Volume Property
    volumeProperty = vtk.vtkVolumeProperty()
    volumeProperty.SetColor(colorFunc)
    volumeProperty.SetScalarOpacity(opacityFunc)
    if use_phong:
        volumeProperty.ShadeOn()
        volumeProperty.SetAmbient(0.5)
        volumeProperty.SetDiffuse(0.5)
        volumeProperty.SetSpecular(0.5)
    else:
        volumeProperty.ShadeOff()

    #Volume Mapper
    volumeMapper = vtk.vtkSmartVolumeMapper()
    volumeMapper.SetInputConnection(reader.GetOutputPort())

    #Volume
    volume = vtk.vtkVolume()
    volume.SetMapper(volumeMapper)
    volume.SetProperty(volumeProperty)

    #Outline
    outline = vtk.vtkOutlineFilter()
    outline.SetInputConnection(reader.GetOutputPort())

    outlineMapper = vtk.vtkPolyDataMapper()
    outlineMapper.SetInputConnection(outline.GetOutputPort())

    outlineActor = vtk.vtkActor()
    outlineActor.SetMapper(outlineMapper)
    outlineActor.GetProperty().SetColor(0, 0, 0)

    #Renderer
    renderer = vtk.vtkRenderer()
    renderer.AddVolume(volume)
    renderer.AddActor(outlineActor)
    renderer.SetBackground(1, 1, 1)

    #Render Window
    renderWindow = vtk.vtkRenderWindow()
    renderWindow.SetSize(1000, 1000)
    renderWindow.AddRenderer(renderer)

    #Interactor
    interactor = vtk.vtkRenderWindowInteractor()
    interactor.SetRenderWindow(renderWindow)

    #Camera Setup - initial position (we now consider this as "back")
    #As we get the back view as the default view otherwise
    camera = renderer.GetActiveCamera()
    camera.SetPosition(0, 0, 1)
    camera.SetFocalPoint(0, 0, 0)
    camera.SetViewUp(0, 1, 0)
    renderer.ResetCamera()
    renderWindow.Render()

    #Save back View (initial view)
    back_w2i = vtk.vtkWindowToImageFilter()
    back_w2i.SetInput(renderWindow)
    back_w2i.Update()

    back_writer = vtk.vtkPNGWriter()
    back_writer.SetFileName("back_view.png")
    back_writer.SetInputConnection(back_w2i.GetOutputPort())
    back_writer.Write()
    print("back view saved as 'back_view.png'")


    #Rotate to front view
    camera.Azimuth(180)
    renderWindow.Render()

    #Save frongt View (after 180-degree rotation)
    front_w2i = vtk.vtkWindowToImageFilter()
    front_w2i.SetInput(renderWindow)
    front_w2i.Update()

    front_writer = vtk.vtkPNGWriter()
    front_writer.SetFileName("front_view.png")
    front_writer.SetInputConnection(front_w2i.GetOutputPort())
    front_writer.Write()
    print("front view saved as 'front_view.png'")


    interactor.Start()

if __name__ == "__main__":
    if len(sys.argv) != 3 or sys.argv[2].lower() not in ["yes", "no"]:
        print("Usage: python part2.py Isabel_3D.vti <yes|no>")
        sys.exit(1)

    vti_file = sys.argv[1]
    use_phong = sys.argv[2].lower() == "yes"

    main(vti_file, use_phong)

